// DOM

const x = document.querySelector('#x');
const btneymar = document.querySelector('#btneymar');
const btcr7 = document.querySelector('#btcr7');
const btmessi = document.querySelector('#btmessi');
const btvini = document.querySelector('#btvini');


// eventos

btneymar.addEventListener('click', neymar);
btmessi.addEventListener('click', messi);
btvini.addEventListener('click', vini);
btcr7.addEventListener('click', cr7);

//função 
function neymar() {
    x.src = 'img/ney.webp'

}

function messi() {
    x.src = 'img/messi.webp'

}
function vini() {
    x.src = 'img/vini.jpg'

}
function cr7() {
    x.src = 'img/cr7.webp'
}